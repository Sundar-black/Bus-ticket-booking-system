import 'package:get/get.dart';

class BookingController extends GetxController {
  var selectedBus = <String, dynamic>{}.obs;
  var selectedSeats = <String>[].obs;

  void selectBus(Map<String, dynamic> bus) {
    selectedBus.value = bus.map((key, value) => MapEntry(key.toString(), value));
    selectedSeats.clear();
  }

  void toggleSeat(String seat) {
    if (selectedSeats.contains(seat)) {
      selectedSeats.remove(seat);
    } else {
      selectedSeats.add(seat);
    }
  }

  double get totalPrice => (selectedSeats.length * (selectedBus['price'] ?? 0)).toDouble();
}
