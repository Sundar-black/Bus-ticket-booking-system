import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'controllers/booking_controller.dart';
import 'screens/bus_list_screen.dart';
import 'screens/seat_selection_screen.dart';
import 'screens/booking_summary_screen.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    Get.put(BookingController());
    return GetMaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Bus Ticket Booking',
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(seedColor: Colors.blue),
        useMaterial3: true,
      ),
      initialRoute: '/',
      getPages: [
        GetPage(name: '/', page: () => BusListScreen()),
        GetPage(name: '/seats', page: () => SeatSelectionScreen()),
        GetPage(name: '/summary', page: () => BookingSummaryScreen()),
      ],
    );
  }
}
