import 'package:flutter/material.dart';
import 'package:get/get.dart';
import '../controllers/booking_controller.dart';

class BusListScreen extends StatelessWidget {
  BusListScreen({super.key});

  final TextEditingController fromCtrl = TextEditingController();
  final TextEditingController toCtrl = TextEditingController();

  final List<Map<String, dynamic>> buses = [
    {"id": 1, "name": "GreenLine Travels", "price": 250, "time": "08:00 AM"},
    {"id": 2, "name": "Red Express", "price": 300, "time": "10:30 AM"},
    {"id": 3, "name": "Blue Horizon", "price": 280, "time": "02:00 PM"},
  ];

  @override
  Widget build(BuildContext context) {
    final bookingController = Get.find<BookingController>();
    return Scaffold(
      appBar: AppBar(title: const Text("Find Buses")),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.all(12),
            child: Row(
              children: [
                Expanded(
                  child: TextField(
                    controller: fromCtrl,
                    decoration: const InputDecoration(
                      labelText: 'From',
                      border: OutlineInputBorder(),
                    ),
                  ),
                ),
                const SizedBox(width: 8),
                Expanded(
                  child: TextField(
                    controller: toCtrl,
                    decoration: const InputDecoration(
                      labelText: 'To',
                      border: OutlineInputBorder(),
                    ),
                  ),
                ),
                const SizedBox(width: 8),
                ElevatedButton(
                  onPressed: () {
                    FocusScope.of(context).unfocus();
                    // In a real app, filter or query here.
                  },
                  child: const Text('Search'),
                )
              ],
            ),
          ),
          const Divider(height: 1),
          Expanded(
            child: ListView.builder(
              itemCount: buses.length,
              itemBuilder: (context, index) {
                final bus = buses[index];
                return Card(
                  margin: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                  child: ListTile(
                    title: Text(bus['name']),
                    subtitle: Text("Time: ${bus['time']}  •  Price: ₹${bus['price']}"),
                    trailing: ElevatedButton(
                      onPressed: () {
                        bookingController.selectBus(bus);
                        Get.toNamed('/seats');
                      },
                      child: const Text("Book"),
                    ),
                  ),
                );
              },
            ),
          ),
        ],
      ),
    );
  }
}
