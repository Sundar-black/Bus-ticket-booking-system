import 'package:flutter/material.dart';
import 'package:get/get.dart';
import '../controllers/booking_controller.dart';

class BookingSummaryScreen extends StatelessWidget {
  const BookingSummaryScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final bookingController = Get.find<BookingController>();

    return Scaffold(
      appBar: AppBar(title: const Text("Booking Summary")),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Obx(() => Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  "Bus: ${bookingController.selectedBus['name']}",
                  style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                ),
                const SizedBox(height: 6),
                Text("Time: ${bookingController.selectedBus['time']}"),
                const SizedBox(height: 12),
                Text(
                  "Seats: ${bookingController.selectedSeats.join(', ')}",
                  style: const TextStyle(fontSize: 16),
                ),
                const SizedBox(height: 12),
                Text(
                  "Total Price: ₹${bookingController.totalPrice.toStringAsFixed(2)}",
                  style: const TextStyle(
                    fontSize: 20,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                const Spacer(),
                SizedBox(
                  width: double.infinity,
                  child: ElevatedButton(
                    onPressed: () {
                      Get.snackbar(
                        "Booking Confirmed",
                        "Your seats have been booked successfully!",
                        snackPosition: SnackPosition.BOTTOM,
                      );
                      Get.offAllNamed('/');
                    },
                    child: const Text("Confirm Booking"),
                  ),
                )
              ],
            )),
      ),
    );
  }
}
