import 'package:flutter/material.dart';
import 'package:get/get.dart';
import '../controllers/booking_controller.dart';

class SeatSelectionScreen extends StatelessWidget {
  SeatSelectionScreen({super.key});

  final seats = List.generate(24, (index) => "S${index + 1}");

  @override
  Widget build(BuildContext context) {
    final bookingController = Get.find<BookingController>();

    return Scaffold(
      appBar: AppBar(title: const Text("Select Seats")),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: GridView.builder(
          gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
            crossAxisCount: 4,
            mainAxisSpacing: 10,
            crossAxisSpacing: 10,
          ),
          itemCount: seats.length,
          itemBuilder: (context, index) {
            final seat = seats[index];
            return Obx(() {
              final isSelected = bookingController.selectedSeats.contains(seat);
              return InkWell(
                onTap: () => bookingController.toggleSeat(seat),
                child: Container(
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(10),
                    border: Border.all(width: 1),
                    color: isSelected ? Colors.greenAccent : Colors.grey.shade200,
                  ),
                  child: Center(
                    child: Text(
                      seat,
                      style: const TextStyle(fontWeight: FontWeight.bold),
                    ),
                  ),
                ),
              );
            });
          },
        ),
      ),
      bottomNavigationBar: Padding(
        padding: const EdgeInsets.fromLTRB(16, 8, 16, 16),
        child: ElevatedButton.icon(
          onPressed: () {
            if (bookingController.selectedSeats.isEmpty) {
              Get.snackbar("No seats", "Please select at least one seat");
            } else {
              Get.toNamed('/summary');
            }
          },
          icon: const Icon(Icons.arrow_forward),
          label: const Text("Continue"),
        ),
      ),
    );
  }
}
